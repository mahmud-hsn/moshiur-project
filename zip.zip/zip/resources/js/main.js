 $(document).ready(function(){
//     var mixer = mixitup('.data-filter');


var mixer = mixitup(containerEl, {
    selectors: {
        target: '.data-filter'
    },
    
});


 });


